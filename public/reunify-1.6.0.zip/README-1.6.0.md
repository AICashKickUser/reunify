# Reunify v1.6.0 — Android App Bundle Release

## Package Information
- **Package ID**: com.aicashkick.reunify
- **Version**: 1.6.0 (versionCode 6)
- **Target SDK**: 36 (Android 16)
- **Min SDK**: 21 (Android 5.0)
- **Host**: reunify-six.vercel.app
- **AAB File**: reunify-1.6.0.aab

## Release Notes

Based on closed testing feedback, we've made significant improvements to make Reunify more usable, reliable, and mobile-friendly on phones.

### Mobile UI Overhaul
- Compact dashboard with smaller stat cards and event items on mobile
- No horizontal scrolling — all views stay within screen width
- Responsive design using mobile-first breakpoints
- Drug testing grid stacks vertically on mobile
- NA meeting tracker is compact with smaller badges
- Parenting class cards have reduced padding on mobile

### Date Display Fix
- Fixed timezone bug where items saved with today's date showed as yesterday
- Now uses local date functions throughout all views and API routes

### Backup & Restore (New Feature)
- JSON backup download for safekeeping
- Email to caseworker with progress data
- Printable court report for hearings
- Restore from backup file

### Other Improvements
- Version number visible in footer and sidebar
- Timeline defaults to list view on mobile
- All cards and events are clickable
- Pro page has proper scroll containment

## Signing Information
- **Keystore**: reunify-key.jks
- **Key Alias**: reunify
- **Signer Certificate**: CN=Reunify, OU=Development, O=AICashKick

## Installation
1. Upload `reunify-1.6.0.aab` to Google Play Console
2. Select the "com.aicashkick.reunify" app
3. Create a new release with this AAB
4. Roll out to production after review

---
Built with @bubblewrap/core v1.24.1 on July 28, 2026
